# Las importaciones al principio
"""En Python, se utiliza la palabra clave import 
para hacer que el código de un módulo esté 
disponible en otro."""
from microbit import *

display.show(Image.HEART)
sleep(1000)

# El código en'while True:' se repite indefinidamente
while True:
    display.show(0) #Contamos cambiando el valor aquí
    sleep(1000)
