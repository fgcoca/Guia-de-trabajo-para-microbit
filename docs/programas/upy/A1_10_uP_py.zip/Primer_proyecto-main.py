# Las importaciones al principio
"""En Python, se utiliza la palabra clave import 
para hacer que el código de un módulo esté 
disponible en otro."""
from microbit import *
display.clear()
display.show(0)
