# Imports go at the top
from microbit import *
display.clear()
while True:
    display.show(Image.HEART_SMALL)
    sleep(300)
    display.show(Image.HEART)
    sleep(300)

